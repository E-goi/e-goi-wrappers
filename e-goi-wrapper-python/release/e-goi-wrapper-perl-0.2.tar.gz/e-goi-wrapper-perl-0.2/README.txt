# Para o SOAP
- SOAPPy: sudo easy_install soappy

# Para o XmlRpc
- xmlrpclib: sudo easy_install xmlrpclib
